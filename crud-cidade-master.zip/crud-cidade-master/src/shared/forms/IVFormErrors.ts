export interface IVFormErrors {
  [key: string]: string;
}